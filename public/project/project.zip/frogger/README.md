frontend-nanodegree-arcade-game
===============================

Run index.html to begin game.

Supporting files:
js/app.js - Primary game file
js/engine.js - Underlying gaming engine
js/resources.js - supplement to gaming engine
css/style.css - styling file
images folder - Contains images of Sprites used in the game
